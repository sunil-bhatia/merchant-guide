package com.thoughtworks.merchant.lineprocessors;

import com.thoughtworks.merchant.lineprocessors.computations.AliasMapManager;
import com.thoughtworks.merchant.lineprocessors.dataobjects.AliasDataObject;
import com.thoughtworks.merchant.lineprocessors.parsers.AliasAssignmentParser;

// Example Alias Assignment Line: "glob is I"
public class AliasAssignmentProcessor {

	public static void process(String line) {

		// Delegate to parser for parsing the line
		AliasDataObject dataObject = AliasAssignmentParser.parse(line);

		// Extract two pieces of info from returned Data Object :
		// galacticSymbol = "glob"
		// romanSymbol = 'I'
		String galacticSymbol = dataObject.getGalacticSymbol();
		Character romanSymbol = dataObject.getRomanSymbol();
		
		// Add Galactic Roman Mapping to the Alias Map 
		AliasMapManager.addMapping(galacticSymbol, romanSymbol);
	}
}
