package com.thoughtworks.merchant.lineprocessors.parsers;

public class OutputLinesFormatter {

	public static String quantityAnswerFormatter(String qtyGalactic, int qtyArabic) {
		String outputLine = "";
		if (qtyArabic != 0) {
			outputLine = qtyGalactic + "is " + qtyArabic;
		}
		return outputLine;
	}

	public static String valueAnswerFormatter(String qtyGalactic, String commodity, double totalValue) {
		String outputLine = "";

		if (totalValue != 0) {
			outputLine = qtyGalactic + commodity + " is " + (long) totalValue + " Credits";
		}

		return outputLine;
	}

	public static String invalidAnswerFormatter() {
		String outputLine = "I have no idea what you are talking about";
		return outputLine;
	}

}
