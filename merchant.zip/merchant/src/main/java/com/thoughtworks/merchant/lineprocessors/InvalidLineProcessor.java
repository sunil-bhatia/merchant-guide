package com.thoughtworks.merchant.lineprocessors;

import com.thoughtworks.merchant.iomanagers.OutputLinesManager;
import com.thoughtworks.merchant.lineprocessors.parsers.OutputLinesFormatter;

// Example Invalid Question Line: "how much wood could a woodchuck chuck if a woodchuck could chuck wood ?"
public class InvalidLineProcessor {

	public static void process() {
		// Delegate to formatter for formatting the output line
		String outputLine = OutputLinesFormatter.invalidAnswerFormatter();

		// Add the answer to the output lines
		OutputLinesManager.addLine(outputLine);
	}
}
