package com.thoughtworks.merchant.lineprocessors.dataobjects;

public class ValueDataObject {
	
    private String commodity;
    private String qtyGalactic;   
    private int value;
    
	public String getCommodity() {
		return commodity;
	}
	public void setCommodity(String commodity) {
		this.commodity = commodity;
	}
	
	public String getQtyGalactic() {
		return qtyGalactic;
	}
	public void setQtyGalactic(String qtyGalactic) {
		this.qtyGalactic = qtyGalactic;
	}

	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
}
