package com.thoughtworks.merchant.interfaces.iomanagers;

import java.util.List;

public interface ListWriter {
	
    public void write(List<String> list, String title);
}
