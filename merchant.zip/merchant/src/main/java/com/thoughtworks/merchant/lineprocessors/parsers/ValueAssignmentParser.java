package com.thoughtworks.merchant.lineprocessors.parsers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.thoughtworks.merchant.iomanagers.LogManager;
import com.thoughtworks.merchant.lineprocessors.computations.GalacticNumerals;
import com.thoughtworks.merchant.lineprocessors.dataobjects.ValueDataObject;

//Example Value Assignment Line: "glob glob Silver is 34 Credits"
public class ValueAssignmentParser {

	private static String rgxValueAssignment = "((?:[a-z]+ )+)([A-Z]\\w+) is (\\d+) Credits$";
	private static Pattern ptn = Pattern.compile(rgxValueAssignment);

	// Parse this line and return the three pieces of information
	// qtyGalactic = "glob glob"
	// commodity = "Silver"
	// value = 34
	public static ValueDataObject parse(String line) {
		Matcher mcher = ptn.matcher(line);
		mcher.matches();

		String qtyGalactic = mcher.group(1);
		String commodity = mcher.group(2);
		int value = Integer.parseInt(mcher.group(3).trim());

		ValueDataObject dataObject = new ValueDataObject();
		dataObject.setQtyGalactic(qtyGalactic);
		dataObject.setCommodity(commodity);
		dataObject.setValue(value);

		return dataObject;
	}

	public static boolean isTypeMatching(String line) {
		boolean isTypeMatching = false;

		// Two conditions have to be met, for this to be true
		// 1. Format should be valid
		// 2. Galactic number should be valid

		boolean isValidFormat = false;
		boolean isValidGalacticNum = false;

		Matcher mcher = ptn.matcher(line);
		// Check if format is valid
		if (mcher.matches()) {
			isValidFormat = true;

			String qtyGalactic = mcher.group(1);
			// Check if galactic num is valid
			if (GalacticNumerals.isValidGalacticNum(qtyGalactic)) {
				isValidGalacticNum = true;
			} else {
				LogManager.add("Invalid Galactic Number in Input Line : " + line);
			}
		}
		
		if (isValidFormat && isValidGalacticNum){
			isTypeMatching = true;
		}

		return isTypeMatching;
	}
}
