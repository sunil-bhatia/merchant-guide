package com.thoughtworks.merchant.lineprocessors.dataobjects;

public class AliasDataObject {
	
	private String galacticSymbol;
	private Character romanSymbol;
	
	public String getGalacticSymbol() {
		return galacticSymbol;
	}
	public void setGalacticSymbol(String galacticSymbol) {
		this.galacticSymbol = galacticSymbol;
	}
	public Character getRomanSymbol() {
		return romanSymbol;
	}
	public void setRomanSymbol(Character romanSymbol) {
		this.romanSymbol = romanSymbol;
	}
}
