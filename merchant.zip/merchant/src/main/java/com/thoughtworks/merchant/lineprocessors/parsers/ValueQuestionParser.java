package com.thoughtworks.merchant.lineprocessors.parsers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.thoughtworks.merchant.iomanagers.LogManager;
import com.thoughtworks.merchant.lineprocessors.computations.CommodityMapManager;
import com.thoughtworks.merchant.lineprocessors.computations.GalacticNumerals;
import com.thoughtworks.merchant.lineprocessors.dataobjects.QuantityDataObject;

//Example Value Question Line: "how many Credits is glob prok Silver ?"
public class ValueQuestionParser {

	private static String rgxValueQuestion = "^how many Credits is ((?:\\w+ )+)([A-Z]\\w+) \\?$";
	private static Pattern ptn = Pattern.compile(rgxValueQuestion);

	// Parse this line and return the two pieces of information
	// qtyGalactic = "glob prok"
    // commodity = "Silver"
	public static QuantityDataObject parse(String line) {
		Matcher mcher = ptn.matcher(line);
		mcher.matches();

		String qtyGalactic = mcher.group(1);
		String commodity = mcher.group(2).trim();
		
		QuantityDataObject dataObject = new QuantityDataObject();
		dataObject.setQtyGalactic(qtyGalactic);
		dataObject.setCommodity(commodity);
        
        return dataObject;
	}

	public static boolean isTypeMatching(String line) {
		boolean isTypeMatching = false;

		// Three conditions have to be met, for this to be true
		// 1. Format should be valid
		// 2. Galactic number should be valid
		// 3. Commodity should be valid

		boolean isValidFormat = false;
		boolean isValidGalacticNum = false;
		boolean isValidCommodity = false;

		Matcher mcher = ptn.matcher(line);
		// Check if format is valid
		if (mcher.matches()) {
			isValidFormat = true;

			String qtyGalactic = mcher.group(1);
			// Check if galactic num is valid
			if (GalacticNumerals.isValidGalacticNum(qtyGalactic)) {
				isValidGalacticNum = true;
			} else {
				LogManager.add("Invalid Galactic Number in Input Line : " + line);
			}
			
			String commodity = mcher.group(2).trim();
			// Check if Commodity is valid
			if (CommodityMapManager.isValidCommodity(commodity)) {
				isValidCommodity = true;
			} else {
				LogManager.add("Invalid Commodity in Input Line : " + line);
			}
		}
		
		if (isValidFormat && isValidGalacticNum && isValidCommodity){
			isTypeMatching = true;
		}

		return isTypeMatching;
	}
}
