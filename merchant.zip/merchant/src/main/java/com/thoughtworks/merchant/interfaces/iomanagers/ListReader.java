package com.thoughtworks.merchant.interfaces.iomanagers;

import java.util.List;

public interface ListReader {
	
	public List<String> read();
}
