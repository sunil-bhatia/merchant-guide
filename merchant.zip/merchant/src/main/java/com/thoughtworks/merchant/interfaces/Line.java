package com.thoughtworks.merchant.interfaces;

public interface Line {

	public void process();
}
