package com.thoughtworks.merchant.interfaces.iomanagers;

public interface LogManager {
	
	public void addLog(String log);

	public void printLog();
}
