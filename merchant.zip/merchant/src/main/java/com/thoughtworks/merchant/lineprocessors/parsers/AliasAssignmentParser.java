package com.thoughtworks.merchant.lineprocessors.parsers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.thoughtworks.merchant.lineprocessors.dataobjects.AliasDataObject;

//Example Alias Assignment Line: "glob is I"
public class AliasAssignmentParser {

	private static String rgxAliasAssignment = "^([a-z]+) is ([I|V|X|L|C|D|M])$";
	private static Pattern ptn = Pattern.compile(rgxAliasAssignment);

	// Parse this line and return the two pieces of information
	// galacticSymbol = "glob"
	// romanSymbol = 'I'
	public static AliasDataObject parse(String line) {

		Matcher mcher = ptn.matcher(line);
		mcher.matches();

		String galacticSymbol = mcher.group(1).trim();
		Character romanSymbol = mcher.group(2).trim().charAt(0);
		
		AliasDataObject dataObject = new AliasDataObject();
		dataObject.setGalacticSymbol(galacticSymbol);
		dataObject.setRomanSymbol(romanSymbol);

		return dataObject;
	}

	public static boolean isTypeMatching(String line) {
		boolean isTypeMatching = false;
		
		Matcher mcher = ptn.matcher(line);
		
		// Check if format is valid
		if (mcher.matches()) {
			isTypeMatching = true;
		}
		
		return isTypeMatching;
	}
}
