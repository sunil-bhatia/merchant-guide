package com.thoughtworks.merchant.lineprocessors;

import com.thoughtworks.merchant.iomanagers.OutputLinesManager;
import com.thoughtworks.merchant.lineprocessors.computations.GalacticNumerals;
import com.thoughtworks.merchant.lineprocessors.parsers.OutputLinesFormatter;
import com.thoughtworks.merchant.lineprocessors.parsers.QuantityQuestionParser;

// Example Quantity Question Line: "how much is pish tegj glob glob ?"
public class QuantityQuestionProcessor {

	public static void process(String line) {

		// Delegate to parser for parsing the line
		// Example: qtyGalactic = "pish tegj glob glob"
        String qtyGalactic = QuantityQuestionParser.parse(line);

    	// Delegate to Galactic Numerals for calculating the answer
        int qtyArabic = GalacticNumerals.galacticToArabic(qtyGalactic);
        
		//Delegate to formatter for formatting the output line
		String outputLine = OutputLinesFormatter.quantityAnswerFormatter(qtyGalactic, qtyArabic);
		
    	//Add the answer to the output lines
		OutputLinesManager.addLine(outputLine);
	}
}
