package com.thoughtworks.merchant.interfaces;

import java.util.List;

public interface ListReader {
	
	public List<String> read();
    
}
