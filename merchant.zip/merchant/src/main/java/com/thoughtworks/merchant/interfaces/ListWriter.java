package com.thoughtworks.merchant.interfaces;

public interface ListWriter {
	
    public void write();
    
}
