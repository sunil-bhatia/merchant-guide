package com.thoughtworks.merchant.lineprocessors.parsers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.thoughtworks.merchant.iomanagers.LogManager;
import com.thoughtworks.merchant.lineprocessors.computations.GalacticNumerals;

//Example Quantity Question Line: "how much is pish tegj glob glob ?"
public class QuantityQuestionParser {

	private static String rgxQuantityQuestion = "^how much is ((?:\\w+[^0-9] )+)\\?$";
	private static Pattern ptn = Pattern.compile(rgxQuantityQuestion);

	// Parse this line and return this piece of information
	// qtyGalactic = "pish tegj glob glob"
	public static String parse(String line) {

		Matcher mcher = ptn.matcher(line);
		mcher.matches();

		String qtyGalactic = mcher.group(1);

		return qtyGalactic;
	}

	public static boolean isTypeMatching(String line) {
		boolean isTypeMatching = false;

		// Two conditions have to be met, for this to be true
		// 1. Format should be valid
		// 2. Galactic number should be valid

		boolean isValidFormat = false;
		boolean isValidGalacticNum = false;

		Matcher mcher = ptn.matcher(line);
		// Check if format is valid
		if (mcher.matches()) {
			isValidFormat = true;

			String qtyGalactic = mcher.group(1);
			// Check if galactic num is valid
			if (GalacticNumerals.isValidGalacticNum(qtyGalactic)) {
				isValidGalacticNum = true;
			} else {
				LogManager.add("Invalid Galactic Number in Input Line : " + line);
			}
		}
		
		if (isValidFormat && isValidGalacticNum){
			isTypeMatching = true;
		}

		return isTypeMatching;
	}
}
