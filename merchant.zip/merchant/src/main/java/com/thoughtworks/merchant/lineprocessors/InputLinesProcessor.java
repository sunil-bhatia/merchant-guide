package com.thoughtworks.merchant.lineprocessors;

import java.util.List;

import com.thoughtworks.merchant.iomanagers.OutputLinesManager;
import com.thoughtworks.merchant.lineprocessors.parsers.AliasAssignmentParser;
import com.thoughtworks.merchant.lineprocessors.parsers.QuantityQuestionParser;
import com.thoughtworks.merchant.lineprocessors.parsers.ValueAssignmentParser;
import com.thoughtworks.merchant.lineprocessors.parsers.ValueQuestionParser;

public class InputLinesProcessor {

	public static List<String> processInputLines(List<String> lines) {
		
		// Process each line
		for (String line : lines) {
			processInputLine(line);
		}

		return OutputLinesManager.getOutputLines();
	}

	// This method checks if an input line is of particular type.
	// If yes, it calls the corresponding line processor
	public static void processInputLine(String line) {

		if (AliasAssignmentParser.isTypeMatching(line)){
			AliasAssignmentProcessor.process(line);
		} 
		else if (ValueAssignmentParser.isTypeMatching(line)){
			ValueAssignmentProcessor.process(line);
		} 
		else if (QuantityQuestionParser.isTypeMatching(line)){
			QuantityQuestionProcessor.process(line);
		} 
		else if (ValueQuestionParser.isTypeMatching(line)){
			ValueQuestionProcessor.process(line);
		} 
		else {
			InvalidLineProcessor.process();
		}
	}
}
