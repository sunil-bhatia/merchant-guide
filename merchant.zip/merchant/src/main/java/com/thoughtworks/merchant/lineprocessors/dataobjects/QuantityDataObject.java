package com.thoughtworks.merchant.lineprocessors.dataobjects;

public class QuantityDataObject {
	
    private String commodity;
    private String qtyGalactic;   

	public String getCommodity() {
		return commodity;
	}
	public void setCommodity(String commodity) {
		this.commodity = commodity;
	}
	
	public String getQtyGalactic() {
		return qtyGalactic;
	}
	public void setQtyGalactic(String qtyGalactic) {
		this.qtyGalactic = qtyGalactic;
	}
}
