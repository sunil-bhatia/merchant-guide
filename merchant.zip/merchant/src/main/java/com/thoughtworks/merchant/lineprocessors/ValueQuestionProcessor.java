package com.thoughtworks.merchant.lineprocessors;

import com.thoughtworks.merchant.iomanagers.OutputLinesManager;
import com.thoughtworks.merchant.lineprocessors.computations.CommodityCalculator;
import com.thoughtworks.merchant.lineprocessors.dataobjects.QuantityDataObject;
import com.thoughtworks.merchant.lineprocessors.parsers.OutputLinesFormatter;
import com.thoughtworks.merchant.lineprocessors.parsers.ValueQuestionParser;

// Example Value Question Line: "how many Credits is glob prok Silver ?"
public class ValueQuestionProcessor {

	public static void process(String line) {
		
		// Delegate to parser for parsing the line
        QuantityDataObject dataObject = ValueQuestionParser.parse(line);
        
		// Extract two pieces of info from returned Data Object :
		// commodity = "Silver"
		// qtyGalactic = "glob prok"
		String commodity = dataObject.getCommodity();
		String qtyGalactic = dataObject.getQtyGalactic();

        // Delegate to Commodity Calculator for calculating the total value for this commodity for the given quantity
        double totalValue = CommodityCalculator.calculateTotalValue(commodity, qtyGalactic);
        	
		//Delegate to formatter for formatting the output line
		String outputLine = OutputLinesFormatter.valueAnswerFormatter(qtyGalactic, commodity, totalValue);
		
    	//Add the answer to the output lines
		OutputLinesManager.addLine(outputLine);
	}
}
