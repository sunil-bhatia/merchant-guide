package com.thoughtworks.merchant.lineprocessors;

import com.thoughtworks.merchant.lineprocessors.computations.CommodityCalculator;
import com.thoughtworks.merchant.lineprocessors.computations.CommodityMapManager;
import com.thoughtworks.merchant.lineprocessors.dataobjects.ValueDataObject;
import com.thoughtworks.merchant.lineprocessors.parsers.ValueAssignmentParser;

// Example Value Assignment Line: "glob glob Silver is 34 Credits"
public class ValueAssignmentProcessor {

	public static void process(String line) {
          
		// Delegate to parser for parsing the line
        ValueDataObject dataObject = ValueAssignmentParser.parse(line);
        
		// Extract three pieces of info from returned Data Object :
		// commodity = "Silver"
		// qtyGalactic = "glob glob"
		// value = 34
		String commodity = dataObject.getCommodity();
		String qtyGalactic = dataObject.getQtyGalactic();
		int value = dataObject.getValue();

        // Delegate to Commodity Calculator for calculating the value per unit quantity for the commodity
		double valuePerUnit = CommodityCalculator.calculateValuePerUnit(value, qtyGalactic);
        
    	// Add commodity and valuePerUnit to the Commodity Value Map 
        CommodityMapManager.addValuePerUnit(commodity, valuePerUnit);
	}
}
