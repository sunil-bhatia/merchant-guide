package com.thoughtworks.merchant.lineprocessors.parsers;
import static org.junit.Assert.*;

import org.junit.Test;

import com.thoughtworks.merchant.lineprocessors.parsers.AliasAssignmentParser;

public class AliasAssignmentParserTest {

	@Test
	public void testValidInputLineReturnsTypeMatch() {
		String line = "glob is I";
		boolean expectedResult = true;
		boolean calculatedResult = AliasAssignmentParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testFiveCharFirstWordReturnsTypeMatch() {
		String line = "globa is I";
		boolean expectedResult = true;
		boolean calculatedResult = AliasAssignmentParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testTwoDigitRomanSymbolReturnsTypeMismatch() {
		String line = "glob is II";
		boolean expectedResult = false;
		boolean calculatedResult = AliasAssignmentParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testWrongRomanSymbolReturnsTypeMismatch() {
		String line = "glob is K";
		boolean expectedResult = false;
		boolean calculatedResult = AliasAssignmentParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testIsMissingReturnsTypeMismatch() {
		String line = "glob in I";
		boolean expectedResult = false;
		boolean calculatedResult = AliasAssignmentParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testFourWordsReturnsTypeMismatch() {
		String line = "glob is I A";
		boolean expectedResult = false;
		boolean calculatedResult = AliasAssignmentParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
}
