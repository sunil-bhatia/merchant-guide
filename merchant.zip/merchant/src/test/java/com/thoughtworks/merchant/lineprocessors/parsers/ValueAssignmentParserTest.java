package com.thoughtworks.merchant.lineprocessors.parsers;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.thoughtworks.merchant.lineprocessors.computations.AliasMapManager;
import com.thoughtworks.merchant.lineprocessors.parsers.ValueAssignmentParser;

public class ValueAssignmentParserTest {
	
    @Before
    public void setupAliasMap() {
    	AliasMapManager.addMapping("glob", 'I');
    	AliasMapManager.addMapping("prok", 'V');
    	AliasMapManager.addMapping("pish", 'X');
    	AliasMapManager.addMapping("tegj", 'L');
    }

	@Test
	public void testValidLineReturnTypeMatch() {
		String line = "glob glob Silver is 34 Credits";
		boolean expectedResult = true;
		boolean calculatedResult = ValueAssignmentParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testCharInsteadOfNumReturnsTypeMismatch() {
		String line = "glob glob Silver is 3a Credits";
		boolean expectedResult = false;
		boolean calculatedResult = ValueAssignmentParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testWrongWordInsteadOfIsReturnsTypeMismatch() {
		String line = "glob glob Silver it 34 Credits";
		boolean expectedResult = false;
		boolean calculatedResult = ValueAssignmentParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testIncorrectGalacticSymbolReturnsTypeMismatch() {
		String line = "cdef Silver it 34 Credits";
		boolean expectedResult = false;
		boolean calculatedResult = ValueAssignmentParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testIncorrectRomanNumReturnsTypeMismatch() {
		String line = "prok prok prok prok Silver is 34 Credits";
		boolean expectedResult = false;
		boolean calculatedResult = ValueAssignmentParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
    @After
    public void teardownAliasMap() {
    	AliasMapManager.getAliasMap().clear();
    }
}
