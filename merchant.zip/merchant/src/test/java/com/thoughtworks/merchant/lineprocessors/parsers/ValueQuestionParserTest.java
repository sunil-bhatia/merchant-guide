package com.thoughtworks.merchant.lineprocessors.parsers;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.thoughtworks.merchant.lineprocessors.computations.AliasMapManager;
import com.thoughtworks.merchant.lineprocessors.computations.CommodityMapManager;
import com.thoughtworks.merchant.lineprocessors.parsers.ValueQuestionParser;

public class ValueQuestionParserTest {
	
    @Before
    public void setupAliasMap() {
    	AliasMapManager.addMapping("glob", 'I');
    	AliasMapManager.addMapping("prok", 'V');
    	AliasMapManager.addMapping("pish", 'X');
    	AliasMapManager.addMapping("tegj", 'L');
    }
    
    @Before
    public void setupCommodityMap() {
    	CommodityMapManager.getCommodityMap().put("Silver", 17.0);
    	CommodityMapManager.getCommodityMap().put("Gold", 14450.0);
    	CommodityMapManager.getCommodityMap().put("Iron", 195.5);
    }

	@Test
	public void testValidLine() {
		String line = "how many Credits is glob prok Silver ?";
		boolean expectedResult = true;
		boolean calculatedResult = ValueQuestionParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testMissingQuestionMark() {
		String line = "how many Credits is glob prok Silver ";
		boolean expectedResult = false;
		boolean calculatedResult = ValueQuestionParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
    @After
    public void teardownAliasMap() {
    	AliasMapManager.getAliasMap().clear();
    	CommodityMapManager.getCommodityMap().clear();
    }
	
}
