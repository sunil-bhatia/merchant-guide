package com.thoughtworks.merchant.lineprocessors.parsers;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.thoughtworks.merchant.lineprocessors.computations.AliasMapManager;
import com.thoughtworks.merchant.lineprocessors.computations.CommodityMapManager;
import com.thoughtworks.merchant.lineprocessors.parsers.QuantityQuestionParser;

public class QuantityQuestionParserTest {
	
    @Before
    public void setupAliasMap() {
    	AliasMapManager.addMapping("glob", 'I');
    	AliasMapManager.addMapping("prok", 'V');
    	AliasMapManager.addMapping("pish", 'X');
    	AliasMapManager.addMapping("tegj", 'L');
    }
    
    @Before
    public void setupCommodityMap() {
    	CommodityMapManager.getCommodityMap().put("Silver", 17.0);
    	CommodityMapManager.getCommodityMap().put("Gold", 14450.0);
    	CommodityMapManager.getCommodityMap().put("Iron", 195.5);
    }

	@Test
	public void testValidLineReturnsTypeMatch() {
		String line = "how much is pish tegj glob glob ?";
		boolean expectedResult = true;
		boolean calculatedResult = QuantityQuestionParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testQuestionMarkMissingReturnsTypeMismatch() {
		String line = "how much is pish tegj glob glob ";
		boolean expectedResult = false;
		boolean calculatedResult = QuantityQuestionParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}

	@Test
	public void testSpaceBeforeQuestionMarkMissingReturnsTypeMismatch() {
		String line = "how much is pish tegj glob glob?";
		boolean expectedResult = false;
		boolean calculatedResult = QuantityQuestionParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testHowMissingReturnsTypeMismatch() {
		String line = "much is pish tegj glob glob ?";
		boolean expectedResult = false;
		boolean calculatedResult = QuantityQuestionParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testExtraWordReturnsTypeMismatch() {
		String line = "how much is pish tegj glob glob ? abc";
		boolean expectedResult = false;
		boolean calculatedResult = QuantityQuestionParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
	@Test
	public void testIncorrectGalacticSymbolReturnsTypeMismatch() {
		String line = "how much is ijkl ?";
		boolean expectedResult = false;
		boolean calculatedResult = QuantityQuestionParser.isTypeMatching(line);
		assertEquals(expectedResult, calculatedResult);
	}
	
    @After
    public void teardownAliasMap() {
    	AliasMapManager.getAliasMap().clear();
    	CommodityMapManager.getCommodityMap().clear();
    }
}
